import React from 'react';
export default function NotFound() {
  return <h1 className="text-2xl font-bold text-red-600">404 - Page Not Found</h1>;
}
