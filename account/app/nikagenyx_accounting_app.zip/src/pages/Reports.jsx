import React from 'react';
export default function Reports() {
  return <h1 className="text-2xl font-bold">Reports</h1>;
}
