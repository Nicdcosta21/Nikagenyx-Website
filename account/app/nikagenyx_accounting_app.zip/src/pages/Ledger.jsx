import React from 'react';
export default function Ledger() {
  return <h1 className="text-2xl font-bold">Ledger</h1>;
}
